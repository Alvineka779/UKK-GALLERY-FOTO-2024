<?php

    //Fungsi Untuk Menyambungkan Antar Database
    $conn = mysqli_connect("localhost","root","","gallery");

?>